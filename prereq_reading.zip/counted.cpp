/*
 * counted.cpp
 *
 *  Created on: Apr 10, 2017
 *      Author: zeil
 */

#include "counted.h"

int Counted::numObjects = 0;


